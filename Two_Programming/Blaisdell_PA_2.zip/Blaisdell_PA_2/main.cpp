/////////////////////////////////////////
//
// Marcus Blaisdell
// CptS 471
// Programming Assignment 2
// March 28, 2019
// Professor Kalyanaraman
//
// Timer code provided by:
// a user whose name has been deleted from reddit:
// 
// https://www.reddit.com/r/learnprogramming/comments/1dlxqv/c_measuring_time_elapsed_in_milliseconds/
//
/////////////////////////////////////////

#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>

using namespace std;

typedef struct node
{
  int nodeID;
  struct node * SL = NULL;
  struct node * parent;
  string edgeLabel;
  vector <struct node * > child;
  int stringDepth;

} aNode;

// global variables

// We will number leaf nodes up from 0:
// We will number internal nodes up from n:

int leafID;
int internalID;
aNode * SLHolder;
// create a pointer to a node to store our current location:
aNode * u;

// readString function

void readFile (string fileName, string *dataName, string *theString)
{
  string line;
  int i = 1;
  //cout << "readFile called" << endl;

  ifstream inputFile (fileName);

    // first line should be information, but verify it

  getline (inputFile, line);

  if (line[0] == '>')
  {
    while (line[i] != ' ' && line[i])
    {
      *dataName += (line[i]);

      i++;

    } // end while loop to get data name

    //getline (inputFile, line);

    while (getline (inputFile, line))
    {
      theString->append (line);

    } // end read the data in

  } // end if data line

} // end function readString


  // findPath function:

void findPath ()
{

} // end findPath function

// caseINH function
// the NodeHop-insert function

void caseINH (string s)
{

  //cout << "\t\t*** caseINH function called ***" << endl;

  // get the number of children:

  int i = u->child.size ();

  for (int j = 0; j < i; j++)
  {
    // the suffix link lets us skip
    // characters to evaluate:

    int k = u->edgeLabel.length ();

    if (u->child[j]->edgeLabel[k] == s[k])
    {
        // if we found a path, follow it
        // as far as we can:

      while (u->child[j]->edgeLabel[k] == s[k])
      {
        k++;
      } // end follow path

      // we are now at the location where we need to
      // insert our new node:
      // first, create new internal node,
      // textLabel = u->child[j]->textLabel.erase (k, (length - k))
      // and a new leaf node
      // textLabel = u->textLabel.erase (0, k)
      //
      // insert-in-order, the new leaf node
      // and existing node (u->child[j])
      // as children of new internal node
      //
      // update existing node parent to
      // new internal node,
      // update existing node textLabel to textLabel.erase (0, k)
      // update existing pointer to u->child to
      // new internal node: u->child[j] = new Internal node
      //
      // set u = new leaf node


      aNode * newInternalNode = new aNode;

      newInternalNode->nodeID = internalID++;
      //struct node * SL;
      newInternalNode->parent = u;
      newInternalNode->edgeLabel = s;
      newInternalNode->edgeLabel.erase(k, (newInternalNode->edgeLabel.length () - k) );
      //vector <struct node * > child;
      newInternalNode->stringDepth = newInternalNode->edgeLabel.length () + u->stringDepth;

      aNode * newLeafNode = new aNode;

      newLeafNode->nodeID = leafID++;
      newLeafNode->parent = newInternalNode;
      newLeafNode->edgeLabel = s;
      newLeafNode->edgeLabel.erase (0, k);
      newLeafNode->stringDepth = newLeafNode->edgeLabel.length () + newInternalNode->stringDepth;

        // update existing node:
      u->child[j]->parent = newInternalNode;
      u->child[j]->edgeLabel.erase (0, k);

      // insert new leaf node and existing node
      // as children of new internal node
      // insert in order:

      if (newLeafNode->edgeLabel == "$" || (newLeafNode->edgeLabel[0] < u->child[j]->edgeLabel[0]) )
      {
        newInternalNode->child.push_back (newLeafNode);
        newInternalNode->child.push_back (u->child[j]);
      } // end if newLeaf is lexicographically lower than existing node
      else
      {
        newInternalNode->child.push_back (u->child[j]);
        newInternalNode->child.push_back (newLeafNode);
      } // end, else existing node is lexicographically lower than leaf

        // now, update existing child pointer to
        // point to the new internal node:

      u->child[j] = newInternalNode;

      u = newLeafNode;

      return;

    } // end if there is a path

  } // end check all children
  //cout << "checked all children, no match" << endl;

  // if we get here, there is no path,
  // create a new leaf node and insert
  // lexicographically

  aNode * newLeafNode = new aNode;

  newLeafNode->nodeID = leafID++;
  newLeafNode->parent = u;
  newLeafNode->edgeLabel = s;
  newLeafNode->stringDepth = s.length () + u->stringDepth;

  //cout << "new leaf node created" << endl;

  vector <aNode *>::iterator it = u->child.begin ();
  int l = 0;

  if (s == "$" || (s[0] < u->child[l]->edgeLabel[0]) )
  {
    u->child.insert (it, newLeafNode);

  } // end insert at beginning
  else
  {
    // iterate to correct position:
    it++;
    l++;
    while ( it != u->child.end ())
    {
      if (u->child[l]->edgeLabel[0] >= s[0])
      {
        u->child.insert (it, newLeafNode);
        break;

      } // end insert before,

      it++;
      l++;

    } // end while
    //cout << "no larger string found, must insert at end" << endl;
    // if we get here, we reached the end of the
    // list without find an insert spot,
    // so we need to insert at the end
    // of the list:

    u->child.push_back (newLeafNode);

  } // end else, insert in order

  u = newLeafNode;


} // end caseINH function

  // NodeHops function:

void NodeHops (string beta, aNode * u_prime, string s, aNode * uPtr)
{
    // take SL(u') to v':

  u = u_prime->SL;

    // take correct path out of v':

  int i = u->child.size ();

  for (int j = 0; j < i; j++)
  {
    if (u->child[j]->edgeLabel[0] == beta[0])
    {
        // once we find the right path, check it's length,
        // if it is greater than beta, then v doesn't exist,
        // we will use findPath and add V
        //
        // if it is less than beta, we don't know if it
        // exists or not but we can safely hop to the child
        // and re-evaluate once we get there
        //
        // if child edgeLabel is equal to beta, then
        // v exists and we can safely hop to the child

      if (beta.length () >= u->child[j]->edgeLabel.length () )
      {
        u = u->child[j];
        break;
      } // end if edgeLabel less than, equal to beta size (v exists)
      else
      {
        caseINH (s);
        return;

      } // end edgeLabel greater than beta size (v doesn't exist)

    } // end find correct child

  } // end iterate through all children

  beta.erase (0, (u->edgeLabel.length () ) );

  if (beta.length () > 0)
  {
    NodeHops (beta, u, s, uPtr);

  } // end recurse until v is found
  else
  {
    // we are now at v:

    // update u suffix link:

    uPtr->SL = u;

    // and insert suffix s:
    u = uPtr;
    caseINH (s);

  } // end found v

} // end NodeHops function

  // caseIA function

void caseIA (string s)
{
  // SL(u) is known,
  // u is the root:

  //cout << "\t\t*** caseIA function called ***" << endl;

  // go to v
  // I am using u as the current position,
  // so in this case, u is v:

  u = u->SL;

  /////
  // get the number of children:

  int i = u->child.size ();

  for (int j = 0; j < i; j++)
  {
    // the suffix link lets us skip
    // characters to evaluate:

    int k = u->edgeLabel.length ();

    if (u->child[j]->edgeLabel[k] == s[k])
    {
        // if we found a path, follow it
        // as far as we can:

      while (u->child[j]->edgeLabel[k] == s[k])
      {
        k++;
      } // end follow path

      // we are now at the location where we need to
      // insert our new node:
      // first, create new internal node,
      // textLabel = u->child[j]->textLabel.erase (k, (length - k))
      // and a new leaf node
      // textLabel = u->textLabel.erase (0, k)
      //
      // insert-in-order, the new leaf node
      // and existing node (u->child[j])
      // as children of new internal node
      //
      // update existing node parent to
      // new internal node,
      // update existing node textLabel to textLabel.erase (0, k)
      // update existing pointer to u->child to
      // new internal node: u->child[j] = new Internal node
      //
      // set u = new leaf node


      aNode * newInternalNode = new aNode;

      newInternalNode->nodeID = internalID++;
      //struct node * SL;
      newInternalNode->parent = u;
      newInternalNode->edgeLabel = s;
      newInternalNode->edgeLabel.erase(k, (newInternalNode->edgeLabel.length () - k) );
      //vector <struct node * > child;
      newInternalNode->stringDepth = newInternalNode->edgeLabel.length () + u->stringDepth;

      aNode * newLeafNode = new aNode;

      newLeafNode->nodeID = leafID++;
      newLeafNode->parent = newInternalNode;
      newLeafNode->edgeLabel = s;
      newLeafNode->edgeLabel.erase (0, k);
      newLeafNode->stringDepth = newLeafNode->edgeLabel.length () + newInternalNode->stringDepth;

        // update existing node:
      u->child[j]->parent = newInternalNode;
      u->child[j]->edgeLabel.erase (0, k);

      // insert new leaf node and existing node
      // as children of new internal node
      // insert in order:

      if (newLeafNode->edgeLabel == "$" || (newLeafNode->edgeLabel[0] < u->child[j]->edgeLabel[0]) )
      {
        newInternalNode->child.push_back (newLeafNode);
        newInternalNode->child.push_back (u->child[j]);
      } // end if newLeaf is lexicographically lower than existing node
      else
      {
        newInternalNode->child.push_back (u->child[j]);
        newInternalNode->child.push_back (newLeafNode);
      } // end, else existing node is lexicographically lower than leaf

        // now, update existing child pointer to
        // point to the new internal node:

      u->child[j] = newInternalNode;

      u = newLeafNode;

      return;

    } // end if there is a path

  } // end check all children
  //cout << "checked all children, no match" << endl;

  // if we get here, there is no path,
  // create a new leaf node and insert
  // lexicographically

  aNode * newLeafNode = new aNode;

  newLeafNode->nodeID = leafID++;
  newLeafNode->parent = u;
  newLeafNode->edgeLabel = s;
  newLeafNode->stringDepth = s.length () + u->stringDepth;

  //cout << "new leaf node created" << endl;

  vector <aNode *>::iterator it = u->child.begin ();
  int l = 0;

  if (s == "$" || (s[0] < u->child[l]->edgeLabel[0]) )
  {
    u->child.insert (it, newLeafNode);

  } // end insert at beginning
  else
  {
    // iterate to correct position:
    it++;
    l++;
    while ( it != u->child.end ())
    {
      if (u->child[l]->edgeLabel[0] >= s[0])
      {
        u->child.insert (it, newLeafNode);
        break;

      } // end insert before,

      it++;
      l++;

    } // end while
    //cout << "no larger string found, must insert at end" << endl;
    // if we get here, we reached the end of the
    // list without find an insert spot,
    // so we need to insert at the end
    // of the list:

    u->child.push_back (newLeafNode);

  } // end else, insert in order

  u = newLeafNode;
  /////


} // end caseIA function

  // caseIB function

void caseIB (string s)
{
  // SL(u) is known,
  // u is the root:

  //cout << "\t\t*** caseIB function called ***" << endl;

  // 1) check if we have a child
  // that begins with the same
  // character as the suffix
  // we are adding:

  // get the number of children:

  int i = u->child.size ();

  for (int j = 0; j < i; j++)
  {
    int k = 0;

    if (u->child[j]->edgeLabel[k] == s[k])
    {
        // if we found a path, follow it
        // as far as we can:

      while (u->child[j]->edgeLabel[k] == s[k])
      {
        k++;
      } // end follow path

      // we are now at the location where we need to
      // insert our new node:
      // first, create new internal node,
      // textLabel = u->child[j]->textLabel.erase (k, (length - k))
      // and a new leaf node
      // textLabel = u->textLabel.erase (0, k)
      //
      // insert-in-order, the new leaf node
      // and existing node (u->child[j])
      // as children of new internal node
      //
      // update existing node parent to
      // new internal node,
      // update existing node textLabel to textLabel.erase (0, k)
      // update existing pointer to u->child to
      // new internal node: u->child[j] = new Internal node
      //
      // set u = new leaf node


      aNode * newInternalNode = new aNode;

      newInternalNode->nodeID = internalID++;
      //struct node * SL;
      newInternalNode->parent = u;
      newInternalNode->edgeLabel = s;
      newInternalNode->edgeLabel.erase(k, (newInternalNode->edgeLabel.length () - k) );
      //vector <struct node * > child;
      newInternalNode->stringDepth = newInternalNode->edgeLabel.length () + u->stringDepth;

      aNode * newLeafNode = new aNode;

      newLeafNode->nodeID = leafID++;
      newLeafNode->parent = newInternalNode;
      newLeafNode->edgeLabel = s;
      newLeafNode->edgeLabel.erase (0, k);
      newLeafNode->stringDepth = newLeafNode->edgeLabel.length () + newInternalNode->stringDepth;

        // update existing node:
      u->child[j]->parent = newInternalNode;
      u->child[j]->edgeLabel.erase (0, k);

      // insert new leaf node and existing node
      // as children of new internal node
      // insert in order:

      if (newLeafNode->edgeLabel == "$" || (newLeafNode->edgeLabel[0] < u->child[j]->edgeLabel[0]) )
      {
        newInternalNode->child.push_back (newLeafNode);
        newInternalNode->child.push_back (u->child[j]);
      } // end if newLeaf is lexicographically lower than existing node
      else
      {
        newInternalNode->child.push_back (u->child[j]);
        newInternalNode->child.push_back (newLeafNode);
      } // end, else existing node is lexicographically lower than leaf

        // now, update existing child pointer to
        // point to the new internal node:

      u->child[j] = newInternalNode;

      u = newLeafNode;

      return;

    } // end if there is a path

  } // end check all children
  //cout << "checked all children, no match" << endl;

  // if we get here, there is no path,
  // create a new leaf node and insert
  // lexicographically

  aNode * newLeafNode = new aNode;

  newLeafNode->nodeID = leafID++;
  newLeafNode->parent = u;
  newLeafNode->edgeLabel = s;
  newLeafNode->stringDepth = s.length () + u->stringDepth;

  //cout << "new leaf node created" << endl;

  vector <aNode *>::iterator it = u->child.begin ();
  int l = 0;

  if (s == "$" || (s[0] < u->child[l]->edgeLabel[0]) )
  {
    u->child.insert (it, newLeafNode);
  } // end insert at beginning
  else
  {
    // iterate to correct position:
    it++;
    l++;
    while ( it != u->child.end ())
    {
      if (u->child[l]->edgeLabel[0] >= s[0])
      {
        u->child.insert (it, newLeafNode);
        break;
      } // end insert before,

      it++;
      l++;

    } // end while
    //cout << "no larger string found, must insert at end" << endl;
    // if we get here, we reached the end of the
    // list without find an insert spot,
    // so we need to insert at the end
    // of the list:

    u->child.push_back (newLeafNode);

  } // end else, insert in order

  u = newLeafNode;

  //cout << "end of caseIB" << endl;
} // end caseIB function

  // caseIIA function

void caseIIA (string s)
{
  // SL(u) is not known,
  // u' is the not the root:

  //cout << "\t\t*** caseIIA function called ***" << endl;

  // Store pointer to u
  // so we can use it
  // to update the suffix link

  aNode * uPtr = u;

  // move to u': u->parent:
  // which should have a suffix link

  u = u->parent;

  if (u->SL != NULL)
  {
    // go to v
    // I am using u as the current position,
    // so in this case, u is v:

    u = u->SL;

    /////
    // get the number of children:

    int i = u->child.size ();

    for (int j = 0; j < i; j++)
    {
      // the suffix link lets us skip
      // characters to evaluate:

      int k = u->edgeLabel.length ();

      if (u->child[j]->edgeLabel[k] == s[k])
      {
          // if we found a path, follow it
          // as far as we can:

        while (u->child[j]->edgeLabel[k] == s[k])
        {
          k++;
        } // end follow path

        // we are now at the location where we need to
        // insert our new node:
        // first, create new internal node,
        // textLabel = u->child[j]->textLabel.erase (k, (length - k))
        // and a new leaf node
        // textLabel = u->textLabel.erase (0, k)
        //
        // insert-in-order, the new leaf node
        // and existing node (u->child[j])
        // as children of new internal node
        //
        // update existing node parent to
        // new internal node,
        // update existing node textLabel to textLabel.erase (0, k)
        // update existing pointer to u->child to
        // new internal node: u->child[j] = new Internal node
        //
        // set u = new leaf node


        aNode * newInternalNode = new aNode;

        newInternalNode->nodeID = internalID++;
        //struct node * SL;
        newInternalNode->parent = u;
        newInternalNode->edgeLabel = s;
        newInternalNode->edgeLabel.erase(k, (newInternalNode->edgeLabel.length () - k) );
        //vector <struct node * > child;
        newInternalNode->stringDepth = newInternalNode->edgeLabel.length () + u->stringDepth;

        aNode * newLeafNode = new aNode;

        newLeafNode->nodeID = leafID++;
        newLeafNode->parent = newInternalNode;
        newLeafNode->edgeLabel = s;
        newLeafNode->edgeLabel.erase (0, k);
        newLeafNode->stringDepth = newLeafNode->edgeLabel.length () + newInternalNode->stringDepth;

          // update existing node:
        u->child[j]->parent = newInternalNode;
        u->child[j]->edgeLabel.erase (0, k);

        // insert new leaf node and existing node
        // as children of new internal node
        // insert in order:

        if (newLeafNode->edgeLabel == "$" || (newLeafNode->edgeLabel[0] < u->child[j]->edgeLabel[0]) )
        {
          newInternalNode->child.push_back (newLeafNode);
          newInternalNode->child.push_back (u->child[j]);
        } // end if newLeaf is lexicographically lower than existing node
        else
        {
          newInternalNode->child.push_back (u->child[j]);
          newInternalNode->child.push_back (newLeafNode);
        } // end, else existing node is lexicographically lower than leaf

          // now, update existing child pointer to
          // point to the new internal node:

        u->child[j] = newInternalNode;
        uPtr->SL = newInternalNode;

        u = newLeafNode;

        return;

      } // end if there is a path

    } // end check all children
    //cout << "checked all children, no match" << endl;

    // if we get here, there is no path,
    // create a new leaf node and insert
    // lexicographically

    aNode * newLeafNode = new aNode;

    newLeafNode->nodeID = leafID++;
    newLeafNode->parent = u;
    newLeafNode->edgeLabel = s;
    newLeafNode->stringDepth = s.length () + u->stringDepth;

    //cout << "new leaf node created" << endl;

    vector <aNode *>::iterator it = u->child.begin ();
    int l = 0;

    if (s == "$" || (s[0] < u->child[l]->edgeLabel[0]) )
    {
      u->child.insert (it, newLeafNode);
      uPtr->SL = u;
    } // end insert at beginning
    else
    {
      // iterate to correct position:
      it++;
      l++;
      while ( it != u->child.end ())
      {
        if (u->child[l]->edgeLabel[0] >= s[0])
        {
          u->child.insert (it, newLeafNode);
          uPtr->SL = u;
          break;
        } // end insert before,

        it++;
        l++;

      } // end while
      //cout << "no larger string found, must insert at end" << endl;
      // if we get here, we reached the end of the
      // list without find an insert spot,
      // so we need to insert at the end
      // of the list:

      u->child.push_back (newLeafNode);
      uPtr->SL = u;

    } // end else, insert in order

    u = newLeafNode;
    /////

  } // end if suffix link is known

} // end caseIIA function

  // caseIIB function

void caseIIB (string s)
{
  // SL(u) is not known,
  // u' is the root:

  //cout << "\t\t*** caseIIB function called ***" << endl;

  // Store pointer to u
  // so we can use it
  // to update the suffix link

  aNode * uPtr = u;

  // move to u': u->parent:
  // which should have a suffix link

  u = u->parent;

  /////
  // get the number of children:

  int i = u->child.size ();

  for (int j = 0; j < i; j++)
  {
    int k = 0;

    if (u->child[j]->edgeLabel[k] == s[k])
    {
        // if we found a path, follow it
        // as far as we can:

      while (u->child[j]->edgeLabel[k] == s[k])
      {
        k++;
      } // end follow path

      // we are now at the location where we need to
      // insert our new node:
      // first, create new internal node,
      // textLabel = u->child[j]->textLabel.erase (k, (length - k))
      // and a new leaf node
      // textLabel = u->textLabel.erase (0, k)
      //
      // insert-in-order, the new leaf node
      // and existing node (u->child[j])
      // as children of new internal node
      //
      // update existing node parent to
      // new internal node,
      // update existing node textLabel to textLabel.erase (0, k)
      // update existing pointer to u->child to
      // new internal node: u->child[j] = new Internal node
      //
      // set u = new leaf node


      aNode * newInternalNode = new aNode;

      newInternalNode->nodeID = internalID++;
      //struct node * SL;
      newInternalNode->parent = u;
      newInternalNode->edgeLabel = s;
      newInternalNode->edgeLabel.erase(k, (newInternalNode->edgeLabel.length () - k) );
      //vector <struct node * > child;
      newInternalNode->stringDepth = newInternalNode->edgeLabel.length () + u->stringDepth;

      aNode * newLeafNode = new aNode;

      newLeafNode->nodeID = leafID++;
      newLeafNode->parent = newInternalNode;
      newLeafNode->edgeLabel = s;
      newLeafNode->edgeLabel.erase (0, k);
      newLeafNode->stringDepth = newLeafNode->edgeLabel.length () + newInternalNode->stringDepth;

        // update existing node:
      u->child[j]->parent = newInternalNode;
      u->child[j]->edgeLabel.erase (0, k);

      // insert new leaf node and existing node
      // as children of new internal node
      // insert in order:

      if (newLeafNode->edgeLabel == "$" || (newLeafNode->edgeLabel[0] < u->child[j]->edgeLabel[0]) )
      {
        newInternalNode->child.push_back (newLeafNode);
        newInternalNode->child.push_back (u->child[j]);
      } // end if newLeaf is lexicographically lower than existing node
      else
      {
        newInternalNode->child.push_back (u->child[j]);
        newInternalNode->child.push_back (newLeafNode);
      } // end, else existing node is lexicographically lower than leaf

        // now, update existing child pointer to
        // point to the new internal node:

      u->child[j] = newInternalNode;
      uPtr->SL = newInternalNode;

      u = newLeafNode;

      return;

    } // end if there is a path

  } // end check all children
  //cout << "checked all children, no match" << endl;

  // if we get here, there is no path,
  // create a new leaf node and insert
  // lexicographically

  aNode * newLeafNode = new aNode;

  newLeafNode->nodeID = leafID++;
  newLeafNode->parent = u;
  newLeafNode->edgeLabel = s;
  newLeafNode->stringDepth = s.length () + u->stringDepth;

  //cout << "new leaf node created" << endl;

  vector <aNode *>::iterator it = u->child.begin ();
  int l = 0;

  if (s == "$" || (s[0] < u->child[l]->edgeLabel[0]) )
  {
    u->child.insert (it, newLeafNode);
    uPtr->SL = u;
  } // end insert at beginning
  else
  {
    // iterate to correct position:
    it++;
    l++;
    while ( it != u->child.end ())
    {
      if (u->child[l]->edgeLabel[0] >= s[0])
      {
        u->child.insert (it, newLeafNode);
        uPtr->SL = u;
        break;
      } // end insert before,

      it++;
      l++;

    } // end while
    //cout << "no larger string found, must insert at end" << endl;
    // if we get here, we reached the end of the
    // list without find an insert spot,
    // so we need to insert at the end
    // of the list:

    u->child.push_back (newLeafNode);
    uPtr->SL = u;

  } // end else, insert in order

  u = newLeafNode;
  /////

} // end caseIIB function

  // insertNode function

void insertNode (string * theData)
{

    // 1) go to u:

  u = u->parent;

    // remove first character from our string:

  string tempString;
  tempString = *theData;
  tempString.erase (0, 1);
  *theData = tempString;

  //cout << "tempString: " << tempString << endl;

    // check if string is now empty,
    // if string is empty, we have completed
    // the suffix tree

  if (theData->length () == 0)
  {
    return;
  } // end if we have completed the tree

  // If the string is not yet empty,
  // continue adding suffixes:
  // determine which of the four cases
  // we have and add the new suffix appropriately:

  else
  {
    if (u->SL == NULL)
    {
      if (u->parent->edgeLabel == "")
      {
          // Case IIB
        caseIIB (*theData);

      } // end is Case IIB
      else
      {
          // Case IIA
        caseIIA (*theData);

      } // end is Case IIA

    } // end if Case II

      // else, SL is not null, it is known:

    else
    {
      if (u->edgeLabel == "")
      {
          // Case IB
        caseIB (*theData);

      } // end is Case IB
      else
      {
          // Case IA
        caseIA (*theData);
      } // end is Case IA

    } // end if Case I

  } // end we have more suffix'es to add


} // end insertNode function


// build a suffix tree:

aNode * buildSFTree (string *theData)
{
    // create a timer:
  auto begin = chrono::high_resolution_clock::now();

    // get the length of string:
    // lowercase n will be the size of the string,
    // uppercase N will be the number of nodes,
    // N = internal nodes + leaf nodes

  int n = theData->length();

    // We will number leaf nodes up from 0:
    // We will number internal nodes up from n:

  leafID = 0;
  internalID = n;

    // create the root node:

  aNode * root = new aNode;

    // root node is a special case that has it's
    // suffix-link point to itself:

  root->SL = root;

    // set root's variables:

    // int nodeID;
    // struct node * SL;
    // struct node * parent;
    // string edgeLabel;
    // vector <struct node * > child;
    // int stringDepth;

  root->nodeID = internalID++;
  // root->SL is already NULL,
  root->parent = root;
  root->edgeLabel = "";
  // root->child starts out empty
  root->stringDepth = 0;

    // create the initial leaf node:

  aNode * newNode = new aNode;

  newNode->nodeID = leafID++;
  // newNode->SL is NULL
  newNode->parent = root;
  newNode->edgeLabel = *theData;
  // newNode child list is empty
  newNode->stringDepth = theData->length();

  root->child.push_back (newNode);

  u = newNode;

    // now, create the remainder of the tree
    // using a while loop that removes the
    // first character from the string on
    // each iteration until the string is
    // empty:

  while (theData->length() > 0)
  {
    insertNode (theData);

  } // end insert until our string is empty

  auto end = chrono::high_resolution_clock::now();
  auto dur = end - begin;
  auto ms = std::chrono::duration_cast<chrono::milliseconds> (dur).count();
  cout << "ms: " << ms << endl;

  return root;

} // end buildSFTree function

  // printDFS function
  // print the tree using
  // depth-first-search

void printDFS (aNode * u)
{
  int i = 0, j = 0;

  if (u->edgeLabel == "")
  {
    // cout << "root" << endl;
    cout << u->nodeID << " : " << u->stringDepth << endl;
  } // end if we are at root, print that


  i = u->child.size ();

    // if no children, just print the edge label

  if (i == 0)
  {
    // Do nothing

  } // end just print edge label
  else
  {
    for (j = 0; j < i; j++)
    {
      //cout << u->child[j]->nodeID << " : " << u->child[j]->edgeLabel << endl;
      cout << u->child[j]->nodeID << " : " << u->child[j]->stringDepth << endl;

      if (u->child[j]->child.size () > 0)
      {
        printDFS (u->child[j]);

      } // end if node has children, recursively print them

    } // end print out all children

  } // end else, print all children

} // end printDFS

int main (int argc, char * argv[])
{
  string fileName;
  string dataName;
  string theData;
  string theAlphabet;
  aNode * root;

    // If no input file was provided,
    // prompt user for one:

  if (argc == 1)
  {
    // prompt user for input file:
    cout << "Enter an input file name: " << endl;
    cin >> fileName;
    cout << "> " << fileName << endl;

  } // end if no argument provided, ask for a file name

  else if (argc == 2)
  {
    // prompt user for input file:
    cout << "Enter an alphabet file name: " << endl;
    cin >> theAlphabet;
    cout << "> " << theAlphabet << endl;

  } // end if no alphabet provided, prompt for one

  else
  {
    fileName = argv[1];
    theAlphabet = argv[2];

  } // end if there is an argument, assume it is the input file name

    // read the data from the file:

  readFile (fileName, &dataName, &theData);

    // append terminating symbol to string:

  theData += '$';

    // create the tree and
    // return a pointer to the root node:

  root = buildSFTree (&theData);

  if (argc == 3)
  {
    if (argv[3] == "-P")
    {
      printDFS (root);

    } // end only printDFS if flagged
  } // end if 3 args


} // end main function
