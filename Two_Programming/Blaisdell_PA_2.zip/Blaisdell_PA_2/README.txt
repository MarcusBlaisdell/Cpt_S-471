Marcus Blaisdell
CptS 487
Programming Assignment #2
March 29, 2019
Professor Kalyanaraman

HOW TO COMPILE:
This is written using C++ syntax and C programming structure.
I compiled it as C++ using:
	g++ main.cpp -o myMain

RUN THE CODE:
It is a simple executable, it can be run from the command line by typing the compiled program name.

NOTES:

This is currently incomplete. 
I have finished creating the suffix tree.
I can report the times for tree constructions.

Not yet implemented:
- header file
- given a pointer to a specific node u in the tree, display u's children from left to right
- break output into lines with 10 entries each
- BWT index
- Write a test "user" code
- Post-Order traversal
- implementation constant
- Exact matching repeat

