Marcus Blaisdell
CptS 487
Programming Assignment #2
March 29, 2019
Professor Kalyanaraman

HOW TO COMPILE:
This is written using C++ syntax and C programming structure.
I compiled it as C++ using:
	g++ main.cpp -o myMain

The header file is "header.h" and is linked in main.cpp via a #include statement.

RUN THE CODE:
It is a simple executable, it can be run from the command line by typing the compiled program name.

NOTES:

Not yet implemented:
- implementation constant
- Exact matching repeat

